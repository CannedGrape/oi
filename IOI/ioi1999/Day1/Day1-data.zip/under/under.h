#ifdef __cplusplus
extern "C"
{
#endif
void start();
void move(char ch);
char look(char ch);
void finish(int x, int y);
#ifdef __cplusplus
}
#endif