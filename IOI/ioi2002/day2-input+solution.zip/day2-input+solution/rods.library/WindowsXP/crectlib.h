#include <stdio.h>
#include <stdlib.h>

#ifdef  __cplusplus
extern "C" {
#endif

int gridsize();
int rect(int a, int b, int c, int d);
void report (int r1, int c1, int r2, int c2, int p1, int q1, int p2, int q2);

#ifdef  __cplusplus
}
#endif
