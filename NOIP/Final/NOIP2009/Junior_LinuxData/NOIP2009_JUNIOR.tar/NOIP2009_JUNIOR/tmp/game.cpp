#include <iostream>
#define mi -1000000000
using namespace std;
int a[1001][1001],i,j,n,m,t,b[1001],c[1001][1001],d[1001][1001][2],e[1001][2];
int ma,x,y,o,de;

void pre()
{
	freopen("game.in","r",stdin);
	scanf("%d%d%d",&m,&n,&t);
	de=n/m*m+m;
	for (i=1;i<=m;i++)
		for (j=1;j<=n;j++)
			scanf("%d",&c[n-j+1][i]);
	for (i=1;i<=m;i++)
		scanf("%d",&b[i]);
	for (i=1;i<=n;i++)
	{
		for (j=1;j<=m;j++)
			a[i][j]=a[i-1][j]+c[i][(j-i+de)%m+1];
	}
}

void work(int o,int ma)
{
	do
	{
		x=d[o][e[o][1]][0];
		y=d[o][e[o][1]][1];
		if (x+a[i][o]-a[y][o]>ma)
			break;
		e[o][1]--;
	}
	while (e[o][1]>=e[j][0]);
	e[o][1]++;
	d[o][e[o][1]][0]=ma;
	d[o][e[o][1]][1]=i;
}

void solve()
{
	for (i=1;i<=m;i++)
		for (j=0;j<2;j++)
			e[i][j]=1;
	for (i=1;i<=n;i++)
	{
		ma=mi;
		for (j=1;j<=m;j++)
		{
			while (d[j][e[j][0]][1]+t<i)
				e[j][0]++;
			y=d[j][e[j][0]][1];
			x=d[j][e[j][0]][0]+a[i][j]-a[y][j]-b[(j-i+de)%m+1];
			if (x>ma)
				ma=x;
		}
		for (j=1;j<=m;j++)
			work(j,ma);
	}
}

void pri()
{
	freopen("game.out","w",stdout);
	printf("%d\n",ma);
}

int main()
{
	pre();
	solve();
	pri();
	return 0;
}