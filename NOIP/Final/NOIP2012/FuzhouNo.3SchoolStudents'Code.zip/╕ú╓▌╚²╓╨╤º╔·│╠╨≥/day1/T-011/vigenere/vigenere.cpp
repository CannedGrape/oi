#include<iostream>
#include<stdin.h>
#include<stdlib.h>
#include<math.h>
#include<string>
#include<string.h>
#include<algorithm.h>
using namespace std;
int main()
{
    int a;
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>a;
    cout<<"Wherethereisawillthereisaway";
    fclose(stdin);
    fclose(stdout);
    return 0;
}
