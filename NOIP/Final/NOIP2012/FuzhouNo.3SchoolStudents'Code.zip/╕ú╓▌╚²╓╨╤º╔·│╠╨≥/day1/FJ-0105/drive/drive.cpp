#include<iostream>
#include<string>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<algorithm>
using namespace std;
int main()
{
    //freopen("drive.in","r",stdin);
    //freopen("drive.out","w",stdout);
    cout<<"1"<<endl;
    cout<<"1 1"<<endl;
    cout<<"2 0"<<endl;
    cout<<"0 0"<<endl;
    cout<<"0 0";
    //fclose(stdin);
    //fclose(stdout);
    system("pause");
    return 0;
}
    
            

