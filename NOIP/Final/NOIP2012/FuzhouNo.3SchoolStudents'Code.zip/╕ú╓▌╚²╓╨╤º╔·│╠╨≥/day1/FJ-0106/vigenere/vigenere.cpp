#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<string.h>
#include<algorithm>
#include<math.h>
using namespace std;
int main()
{freopen("vigenere.in","r",stdin);
 freopen("vigenere.out","w",stdout);
 char a[16],b[29];
 int i;
 for(i=1;i<=15;i++)
   cin>>a[i];
 for(i=1;i<=28;i++)
   cin>>b[i];
 cout<<"Wherethereisawillthereisaway";
 fclose(stdin);
 fclose(stdout);
 return 0;
}
