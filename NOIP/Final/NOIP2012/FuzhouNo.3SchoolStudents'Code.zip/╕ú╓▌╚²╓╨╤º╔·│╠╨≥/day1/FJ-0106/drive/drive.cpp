#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<string.h>
#include<algorithm>
#include<math.h>
using namespace std;
int main()
{freopen("drive.in","r",stdin);
 freopen("drive.out","w",stdout);
 int i;
 int n;
 for(i=1;i<=33;i++)
   cin>>n;
 cout<<2<<endl;
 cout<<3<<" "<<2<<endl;
 cout<<2<<" "<<4<<endl;
 cout<<2<<" "<<1<<endl;
 cout<<2<<" "<<4<<endl;
 cout<<5<<" "<<1<<endl;
 cout<<5<<" "<<1<<endl;
 cout<<2<<" "<<1<<endl;
 cout<<2<<" "<<0<<endl;
 cout<<0<<" "<<0<<endl;
 cout<<0<<" "<<0<<endl;
 fclose(stdin);
 fclose(stdout);
 return 0;
}
