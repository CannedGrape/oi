#include <iostream>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <algorithm>
#define MXN 1000010
using namespace std;
int main ()
{
    freopen("blockade.in","r",stdin);
    freopen("blockade.out","w",stdout);
    cout<<"-1"<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}
