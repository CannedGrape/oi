#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <memory.h>
#include <math.h>
#include <string>
#include <string.h>
#include <cstring>
#include <map>
#include <set>
#include <stdlib.h>
using namespace std;
#define rep(i,a,b)  for(int i=(a);i<=(b);i++)
#define down(i,a,b) for(int i=(a);i>=(b);i--)
const int maxn = 1001;
int main(){
	freopen("blockade.in","r",stdin);
	freopen("blockade.out","w",stdout);
	printf("-1\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
