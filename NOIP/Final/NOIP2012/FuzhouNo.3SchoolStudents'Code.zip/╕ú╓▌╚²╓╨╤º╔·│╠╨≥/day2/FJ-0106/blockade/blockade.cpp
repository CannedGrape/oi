#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<math.h>
#include<cmath>
#include<string.h>
#include<string>
#include<fstream>
using namespace std;
int main()
{
 freopen("blockade.in","r",stdin);
 freopen("blockade.out","w",stdout);
 cout<<"-1";
 fclose(stdin);
 fclose(stdout);
 return 0;
}
