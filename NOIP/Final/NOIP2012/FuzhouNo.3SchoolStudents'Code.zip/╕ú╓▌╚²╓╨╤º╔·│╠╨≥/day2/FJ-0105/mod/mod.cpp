#include<iostream>
#include<string>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<algorithm>
using namespace std;
int main()
{
    freopen("mod.in","r",stdin);
    freopen("mod.out","w",stdout);
    cout<<7;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
