#include<iostream>
#include<string>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<algorithm>
using namespace std;
int main()
{
    freopen("blockade.in","r",stdin);
    freopen("blockade.out","w",stdout);
    cout<<-1;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
