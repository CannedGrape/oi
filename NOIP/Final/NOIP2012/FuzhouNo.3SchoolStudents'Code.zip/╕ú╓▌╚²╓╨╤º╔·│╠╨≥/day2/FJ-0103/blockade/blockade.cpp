#include<iostream>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
    freopen("blockade.in","r",stdin);
    freopen("blockade.out","w",stdout);
    printf("-1\n");
    fclose(stdin);
    fclose(stdout);
    return 0;
}
