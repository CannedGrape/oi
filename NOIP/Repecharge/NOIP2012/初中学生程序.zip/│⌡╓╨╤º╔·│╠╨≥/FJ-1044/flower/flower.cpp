#include<iostream>
#include<string.h>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
using namespace std;
int main()
{
    //freopen("flower.in","r",stdin);
    //freopen("flower.out","w",stdout);
    
    system("pause");
    //fclose(stdin);
    //fclose(srdout);
}
