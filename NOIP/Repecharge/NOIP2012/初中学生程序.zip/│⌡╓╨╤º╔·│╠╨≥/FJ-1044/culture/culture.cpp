#include<iostream>
#include<string.h>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
using namespace std;
int main()
{
    freopen("culture.in","r",stdin);
    freopen("culture.out","w",stdout);
    cout<<"-1";
    //system("pause");
    fclose(stdin);
    fclose(stdout);
    return 0;
}
