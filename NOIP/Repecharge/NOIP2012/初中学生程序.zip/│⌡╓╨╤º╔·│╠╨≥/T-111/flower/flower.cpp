#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int main()
{
   freopen("flower.in","r",stdin);
   freopen("flower.out","w",stdout);
   cout<<"2";
   fclose(stdin);
   fclose(stdout);   
   return 0;
}
