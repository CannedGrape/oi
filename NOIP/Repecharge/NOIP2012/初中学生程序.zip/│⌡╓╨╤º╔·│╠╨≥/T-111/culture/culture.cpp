#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int main()
{
   freopen("culture.in","r",stdin);
   freopen("culture.out","w",stdout);
   cout<<"-1";
   fclose(stdin);
   fclose(stdout);   
   return 0;
}
