#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    freopen("culture.in","r",stdin);
    freopen("culture.out","w",stdout);
    cout<<"-1\n";
    fclose(stdin);
    fclose(stdout);
    return 0;
}
