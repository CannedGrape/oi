#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
int n,m,k=0,a[1000];
using namespace std;
int main()
{
    freopen("culture.in","r",stdin);
    freopen("culture.out","w",stdout);
    cout<<-1<<endl;
    fclose(stdout);
    fclose(stdin);
    //system("pause");
    return 0;
}

