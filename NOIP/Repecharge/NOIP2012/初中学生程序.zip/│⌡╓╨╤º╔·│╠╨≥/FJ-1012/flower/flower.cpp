#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <algorithm>
#include <string.h>
using namespace std;
int n,m;
int a[101];
int b[101];
int main()
{  freopen("flower.in","r",stdin);
   freopen("flower.out","w",stdout);
   int i;
   cin>>n>>m;
   for (i=1;i<=n;i++)
     cin>>a[i];
   cout<<"2"<<endl;
   fclose(stdin);
   fclose(stdout);
return 0;
}
