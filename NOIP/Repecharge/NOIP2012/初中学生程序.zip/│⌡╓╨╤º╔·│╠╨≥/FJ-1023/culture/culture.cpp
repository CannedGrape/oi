#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<math.h>
#include<string>
#include<string.h>
using namespace std;
int main()
{
    freopen("culture.in","r",stdin);
    freopen("culture.out","w",stdout);
    cout<<-1;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
