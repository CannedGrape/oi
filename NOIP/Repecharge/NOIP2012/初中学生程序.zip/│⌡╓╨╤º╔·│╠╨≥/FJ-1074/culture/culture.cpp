#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<string>
#include<algorithm>
#include<math.h>
using namespace std;
int main()
{
  freopen("culture.in","r",stdin);
  freopen("culture.out","w",stdout);
  printf("-1");
  fclose(stdin);
  fclose(stdout);
  return 0;
}
