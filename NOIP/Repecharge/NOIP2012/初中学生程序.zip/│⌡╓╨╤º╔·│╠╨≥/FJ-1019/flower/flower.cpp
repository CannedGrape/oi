#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<string>
#include<algorithm>
#include<math.h>
using namespace std;
int main()
{
   freopen("flower.in","r",stdin);
   freopen("flower.out","w",stdout);
   int n;
   cin>>n;
   cout<<n;
	fclose(stdin);
	fclose(stdout);
   return 0; 
}
