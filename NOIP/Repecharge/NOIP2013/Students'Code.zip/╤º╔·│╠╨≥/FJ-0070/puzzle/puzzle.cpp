#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<stdio.h>
using namespace std;
int main ()
{
    freopen ("puzzle.in","r",stdin);
    freopen ("puzzle.out","w",stdout);

    cout<<-1;
    
    //system("pause");
    return 0;
}
