#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<cstdio>
using namespace std;
int main()
{
    int n,i;
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    cin>>a[
    for(i=1;i<=n;i++)
      
    fclose(stdin);
    fclose(stdout);
    return 0;
}
