#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;

int main ()
{
    freopen ("puzzle.in","r",stdin);
    freopen ("puzzle.out","w",stdout);
    cout<<"-1"<<endl;
    //system ("pause");
    return 0;
}
