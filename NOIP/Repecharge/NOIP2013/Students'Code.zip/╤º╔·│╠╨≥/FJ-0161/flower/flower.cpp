#include<iostream>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<string.h>
using namespace std;
long long n;
long long duilie[100000],tmp[100000];
long long m[100000];
int main()
{
        freopen("flower.in","r",stdin);
    freopen("flower.out","w",stdout);
   long long i; 
   scanf("%lld", &n);
   for(i=1;i<=n;i++)
     {
     scanf("%lld", &m[i]);
     }
     cout<<1;
    cout<<'\n';
    fclose(stdin);
    fclose(stdout);
    return 0;
}
