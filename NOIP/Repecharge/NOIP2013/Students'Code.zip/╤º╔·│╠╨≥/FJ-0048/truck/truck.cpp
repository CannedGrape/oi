#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;


int main()
{
    freopen("truck.in","r",stdin);
    freopen("truck.out","w",stdout);
    cout<<"3"<<endl;
    cout<<"-1"<<endl;
    cout<<"3"<<endl;
}
