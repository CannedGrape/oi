#include<iostream>
#include<string>
#include<string.h>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
using namespace std;
int main()
{
    freopen("truck.in","r",stdin);
    freopen("truck.out","w",stdout);
    int n;
    cin>>n;
    cout<<3<<endl<<-1<<endl<<3<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
