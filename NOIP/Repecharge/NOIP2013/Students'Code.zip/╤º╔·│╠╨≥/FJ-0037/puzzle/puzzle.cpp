#include<iostream>
using namespace std;
int main()
{
  freopen("puzzle.in","r",stdin);
  freopen("puzzle.out","w",stdout);
  cout<<"-1";
  fclose(stdin);
  fclose(stdout);
  return 0;
}
