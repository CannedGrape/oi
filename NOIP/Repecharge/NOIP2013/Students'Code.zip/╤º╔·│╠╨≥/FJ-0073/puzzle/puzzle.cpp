#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<string>
using namespace std;
int n,m,q;
int main()
{freopen("puzzle.in","r",stdin);
  freopen("puzzle.out","w",stdout);
 scanf("%d%d%d",&n,&m,&q);
 for(int i=1;i<=q;i++)printf("-1");  
return 0;	
}