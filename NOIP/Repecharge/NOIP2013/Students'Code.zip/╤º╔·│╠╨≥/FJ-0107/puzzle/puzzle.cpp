#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<windows.h>
using namespace std;

int main(){
    freopen("puzzle.in","r",stdin);
    freopen("puzzle.out","w",stdout);
    cout<<-1;
    return 0;
}
