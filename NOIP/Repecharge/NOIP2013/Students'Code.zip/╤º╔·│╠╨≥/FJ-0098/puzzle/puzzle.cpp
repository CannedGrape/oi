#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("puzzle.in","r",stdin);
    freopen("puzzle.out","w",stdout);
    int n,m,q,tmp;
    cin>>n>>m>>q;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
    cin>>tmp;
    for(int i=1;i<=q;i++)
    cout<<1<<endl;
    return 0;
}
