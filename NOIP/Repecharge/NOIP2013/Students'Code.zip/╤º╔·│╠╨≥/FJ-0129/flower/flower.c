#include<stdio.h>
int main()
{
    freopen("flower.in","r",stdin);
    freopen("flower.out","w",stdout);
    return 0;
}
