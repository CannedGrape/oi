#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
    freopen("match.in","r",stdin);
    freopen("match.out","w",stdout);
    printf("0\n");
    return 0;
}
