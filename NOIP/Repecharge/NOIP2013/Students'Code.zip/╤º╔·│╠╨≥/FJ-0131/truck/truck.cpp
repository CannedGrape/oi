#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
    freopen("truck.in","r",stdin);
    freopen("truck.out","w",stdout);
    cout<<"3"<<endl;
    cout<<"-1"<<endl
    cout<<"3"<<endl;
    return 0;
}
