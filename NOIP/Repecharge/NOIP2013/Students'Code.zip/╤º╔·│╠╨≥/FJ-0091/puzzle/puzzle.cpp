#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <cmath>
#include <cstring>
#include <string>
using namespace std;
int n,m,q;
int main()
{
    freopen ("puzzle.in", "r", stdin);
    freopen ("puzzle.out","w",stdout);
    cin>>n>>m>>q;
    for (int i=1; i<=q; i++) cout<<-1<<endl;
    return 0;
}
