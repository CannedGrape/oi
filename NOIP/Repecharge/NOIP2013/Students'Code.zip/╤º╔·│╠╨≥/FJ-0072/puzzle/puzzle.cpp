#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    freopen("puzzle.out", "w", stdout);
    cout << "2\n-1\n";
    fclose(stdout);
    return 0;
}
