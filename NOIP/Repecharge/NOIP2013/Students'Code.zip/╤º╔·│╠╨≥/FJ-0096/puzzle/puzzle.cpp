#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
#include<string>
#include<set>
using namespace std;
int main()
{
freopen("puzzle.in","r",stdin); freopen("puzzle.out","w",stdout);
printf("2\n-1\n");
fclose(stdin);fclose(stdout);
return 0;
}
