void init(void);
void put_sign(void);
void take_sign(void);
void walk(int);
void look(int *,int *);
void report(int,int);

