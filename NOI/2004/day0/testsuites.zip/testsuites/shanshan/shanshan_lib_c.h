#ifndef SHANSHAN_LIB_C
#define SHANSHAN_LIB_C

void 	init();
int 	show(int s1, int s2, int s3);
void 	answer(int x);

#endif